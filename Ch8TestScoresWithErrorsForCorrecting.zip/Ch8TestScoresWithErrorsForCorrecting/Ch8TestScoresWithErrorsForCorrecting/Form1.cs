﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch8TestScoresWithErrorsForCorrecting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Declare the field variables

        int totalScoreCount = 0; // public variables plus default value 0
        int runningCount = 0;

        // Declare the array, but don't initilize it or define its size
        // The size will be determined based upon user input from the
        // examNumberButton event handler

        double[] examScores; // changed decleration of the array

        private void displayButton_Click(object sender, EventArgs e)
        {
            // display the array

            string output = ""; // outputs needs to be empty
            double total = 0; // declaring 0 as a default value
            double avg = 0;

            foreach (double element in examScores)
            {
                output = output + element + "\n";
                total = total + element;

            }

            // calc the average

            avg = total / examScores.Length; // average division by Length of the array

            MessageBox.Show(output + "\n"
                            + "The average is:  " + avg.ToString("n0")); // avg into STRING not total

            // invoke the show prompt method

            ShowScoreCountEntries();

        }

        private void examNumberButton_Click(object sender, EventArgs e)
        {
            // enter the number of exam scores for the array

            totalScoreCount = Convert.ToInt16(numExamsTextbox.Text); // converting to Integer

            // define the size of the examScores array

            examScores = new double [totalScoreCount]; // declaring the size of the array

            // hide test entires  call a method to hide

            HideExamEntries();
        }


        private void HideExamEntries()
        {
            // hide the exam entry stuff

            enterExamsLabel.Visible = false; 
            numExamsTextbox.Visible = true;
            examNumberButton.Visible = false; //changed to false

            // display the exam score number to enter

            examScoreLabel.Text = "Enter Score " + (runningCount + 1); // display exam number
            examScoreLabel.Visible = true;
            examScoreTextbox.Visible = true;
            addButton.Visible = true; // changed to true
            examScoreTextbox.Focus();

        }


        private void ShowScoreCountEntries()
        {
            enterExamsLabel.Visible = true;
            numExamsTextbox.Visible = true;
            examNumberButton.Visible = true;

           
            // reset the totals and counts

            totalScoreCount = 0; // reseting score count to 0
            runningCount = -0;

            // clear the exam score text box
            examScoreTextbox.Text = ""; // clear the text box

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (runningCount < totalScoreCount) // less than <
            {
                // get score

                double score = Convert.ToDouble(examScoreTextbox.Text);

                // add to array

                examScores[runningCount] = score; // assiging score to the array

                runningCount++; // running count ++;


                if (runningCount < totalScoreCount) // equal

                {
                    // prompt for next score

                    examScoreLabel.Text = "Enter Score " + (runningCount + 1);
                    examScoreTextbox.Text = ""; // uncomment 
                    examScoreTextbox.Focus(); //uncomment

                }

                else
                {
                    // hide the exam number label and exam score entry
                    // and show show a message that all scores are entered.

                    examScoreLabel.Hide();
                    examScoreTextbox.Hide();
                    addButton.Hide();

                    MessageBox.Show("All the exam scores have been entered. Click the Display Scores button for errors.", 
                                    "Exam Scores Complete", MessageBoxButtons.OK, MessageBoxIcon.Information); // check this, not sure if it's correct

                }

            }
        }
    }
}
