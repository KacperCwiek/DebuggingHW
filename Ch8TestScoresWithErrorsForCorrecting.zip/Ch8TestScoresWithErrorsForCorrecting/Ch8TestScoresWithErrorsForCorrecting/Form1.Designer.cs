﻿namespace Ch8TestScoresWithErrorsForCorrecting
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.examNumberButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.examScoreTextbox = new System.Windows.Forms.TextBox();
            this.examScoreLabel = new System.Windows.Forms.Label();
            this.numExamsTextbox = new System.Windows.Forms.TextBox();
            this.enterExamsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // examNumberButton
            // 
            this.examNumberButton.Location = new System.Drawing.Point(282, 45);
            this.examNumberButton.Name = "examNumberButton";
            this.examNumberButton.Size = new System.Drawing.Size(68, 19);
            this.examNumberButton.TabIndex = 13;
            this.examNumberButton.Text = "Enter";
            this.examNumberButton.UseVisualStyleBackColor = true;
            this.examNumberButton.Click += new System.EventHandler(this.examNumberButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(159, 158);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(122, 50);
            this.displayButton.TabIndex = 12;
            this.displayButton.Text = "Display Scores and Average";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(231, 90);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(65, 20);
            this.addButton.TabIndex = 11;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Visible = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // examScoreTextbox
            // 
            this.examScoreTextbox.Location = new System.Drawing.Point(159, 87);
            this.examScoreTextbox.Name = "examScoreTextbox";
            this.examScoreTextbox.Size = new System.Drawing.Size(55, 20);
            this.examScoreTextbox.TabIndex = 10;
            this.examScoreTextbox.Visible = false;
            // 
            // examScoreLabel
            // 
            this.examScoreLabel.AutoSize = true;
            this.examScoreLabel.Location = new System.Drawing.Point(84, 90);
            this.examScoreLabel.Name = "examScoreLabel";
            this.examScoreLabel.Size = new System.Drawing.Size(49, 13);
            this.examScoreLabel.TabIndex = 9;
            this.examScoreLabel.Text = "Exam #  ";
            this.examScoreLabel.Visible = false;
            // 
            // numExamsTextbox
            // 
            this.numExamsTextbox.Location = new System.Drawing.Point(159, 45);
            this.numExamsTextbox.Name = "numExamsTextbox";
            this.numExamsTextbox.Size = new System.Drawing.Size(100, 20);
            this.numExamsTextbox.TabIndex = 8;
            // 
            // enterExamsLabel
            // 
            this.enterExamsLabel.AutoSize = true;
            this.enterExamsLabel.Location = new System.Drawing.Point(28, 45);
            this.enterExamsLabel.Name = "enterExamsLabel";
            this.enterExamsLabel.Size = new System.Drawing.Size(115, 13);
            this.enterExamsLabel.TabIndex = 7;
            this.enterExamsLabel.Text = "Enter number of exams";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 326);
            this.Controls.Add(this.examNumberButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.examScoreTextbox);
            this.Controls.Add(this.examScoreLabel);
            this.Controls.Add(this.numExamsTextbox);
            this.Controls.Add(this.enterExamsLabel);
            this.Name = "Form1";
            this.Text = "Exam Scores With Errors for Correcting";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button examNumberButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.TextBox examScoreTextbox;
        private System.Windows.Forms.Label examScoreLabel;
        private System.Windows.Forms.TextBox numExamsTextbox;
        private System.Windows.Forms.Label enterExamsLabel;
    }
}

